# Online-Book-Store
Front-end Project

Tasks:
  1. Implement a home page of an online book store
  2. Implement a login and a register page of the online book store
  3. Implement a shopping cart page 

Techniques: HTML, CSS, JAVASCRIPT

Instructions:
  This is a simple Front End project. You can open it directly with your browser (start from index.html). Or you can deploy it on your server(such as Tomcat), and access it by URL.By clicking on login, register  and shopping cart button, you can jump to the corresponding pages.
  
